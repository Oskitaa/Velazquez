<style>
    body{
        display:flex;
        align-items:center;
        justify-content:center;
        padding:0;
        margin:0;
    }
    a{
        text-decoration: none;
    }

    button{
        font-size:40px;
    }
</style>
<div>
    <button><a href="/categorias">Categorias</a></button>
    <button><a href="/cursos">Cursos</a></button>
    <button><a href="/alumnos">Alumnos</a></button>   
</div>