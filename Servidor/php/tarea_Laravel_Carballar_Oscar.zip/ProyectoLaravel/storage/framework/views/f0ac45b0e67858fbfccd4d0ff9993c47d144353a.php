

<?php $__env->startSection("cabecera"); ?>

<h2>Información de la Categoria</h2>

<table border ="1">
	
<tr>
		<th>Nombre</th>
		<th>Descripcion</th>
	</tr>
	<tr>
		<td><?php echo e($categoria->nombre); ?></td>
		<td><?php echo e($categoria->descripcion); ?></td>
	</tr>
	<tr>
		<td colspan="2"><a href="/categorias">Volver</a></td>
	</tr>
</table>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make("../layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProyectoLaravel\resources\views/categorias/show.blade.php ENDPATH**/ ?>