

<?php $__env->startSection("inicio"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("cabecera"); ?>
	<h2>Actualizar categoria</h2>

	<form method="post" action="/categorias/<?php echo e($categoria->id); ?>">
		<?php echo method_field("PUT"); ?>
		<?php echo csrf_field(); ?>
		<table>
			<tr>
				<td>Nombre</td>
				<td><input type="text" name="nombre" value="<?php echo e($categoria->nombre); ?>"></td>
			</tr>
			<tr>
				<td>Descripcion</td>
				<td><input type="text" name="descripcion" value="<?php echo e($categoria->descripcion); ?>"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="enviar" value="Actualizar"></td>
			</tr>
		</table>
	</form>
	<?php if($errors->any()): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
	<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make("../layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProyectoLaravel\resources\views/categorias/edit.blade.php ENDPATH**/ ?>