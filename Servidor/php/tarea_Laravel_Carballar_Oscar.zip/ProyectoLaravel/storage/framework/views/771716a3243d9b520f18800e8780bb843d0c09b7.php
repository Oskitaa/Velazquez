

<?php $__env->startSection("cabecera"); ?>
	<h2>Insertar un nuevo alumno</h2>

	<form method="post" action="/alumnos">
		<?php echo csrf_field(); ?>
		<table>
			<tr>
				<td>Nombre<input type="text" name="nombre"></td>
			</tr>
			<tr>
				<td>Apellidos<input type="text" name="apellidos"></td>
			</tr>
			<tr>
			<td>Edad<input type="text" name="edad"></td>
			</tr>
			<tr>
			<select name="curso">
					<option value="">Seleccione un curso</option>
					<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value=<?php echo e($curso->id); ?> ><?php echo e($curso->nombre); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select></tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="enviar" value="Enviar"></td>
			</tr>
		</table>
	</form>
	<?php if($errors->any()): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
	<?php endif; ?>
<?php $__env->stopSection(); ?> 


<?php echo $__env->make("../layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProyectoLaravel\resources\views/alumnos/create.blade.php ENDPATH**/ ?>