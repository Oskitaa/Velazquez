

<?php $__env->startSection("cabecera"); ?>
	Listado de Centros
<?php $__env->stopSection(); ?>

<?php $__env->startSection("cuerpo"); ?>
<table border ="1">
	<tr>
		<th>Nombre</th>
		<th>Acciones</th>
	</tr>


	<?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($centro->nombre); ?></td>
		<td align="center"><a href="<?php echo e(route('centros.edit', $centro->id)); ?>">editar</a> - <a href="<?php echo e(route('centros.show', $centro->id)); ?>">mostrar</a></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td colspan="2" align="center"><a href="<?php echo e(route('centros.create')); ?>">Nuevo centro</a></td>
	</tr>
</table>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection("pie"); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make("../layouts.plantilla", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProjectoLaravel\resources\views/cursos/index.blade.php ENDPATH**/ ?>