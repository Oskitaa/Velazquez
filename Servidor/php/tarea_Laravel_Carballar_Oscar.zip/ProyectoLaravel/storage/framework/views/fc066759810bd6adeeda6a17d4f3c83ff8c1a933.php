

<?php $__env->startSection("inicio"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("cabecera"); ?>

<h2>Listado de Categorias</h2>


<table border ="1">
	<tr>
		<th>Nombre</th>
		<th>Acciones</th>
	</tr>


	<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	

	<tr>
		<td><?php echo e($categoria->nombre); ?></td>
		<td align="center">
			<button><a href="<?php echo e(route('categorias.edit', $categoria->id)); ?>">Editar</a> </button> 
			<button><a href="<?php echo e(route('categorias.show', $categoria->id)); ?>">Mostrar</a> </button>
			<form action="/categorias/<?php echo e($categoria->id); ?>" method="post">
				<?php echo csrf_field(); ?>
				<?php echo method_field("delete"); ?>
				<button type="submit" <?php if(count($categoria->curso) >0 ): ?> disabled <?php endif; ?>>Borrar</button>
			</form>
	</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td colspan="2" align="center"><a href="<?php echo e(route('categorias.create')); ?>">Nueva categoria</a></td>
	</tr>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("../layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProyectoLaravel\resources\views/categorias/index.blade.php ENDPATH**/ ?>