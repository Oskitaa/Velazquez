

<?php $__env->startSection("inicio"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("cabecera"); ?>

	<h2>Listado de Cursos</h2>


<table border ="1">
	<tr>
		<th>Nombre</th>
		<th>Número alumnos</th>
		<th>Plazas disponibles</th>
		<th>Acciones</th>
	</tr>


	<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($curso->nombre); ?></td>
		<td><?php echo e($curso->plazas); ?></td>
		<td> <?php if(count($curso->alumno) >= $curso->plazas): ?> No <?php else: ?> Si <?php endif; ?></td>
		<td align="center">
			<button><a href="<?php echo e(route('cursos.edit', $curso->id)); ?>">Editar</a> </button> 
			<button><a href="<?php echo e(route('cursos.show', $curso->id)); ?>">Mostrar</a> </button>
			<form action="/cursos/<?php echo e($curso->id); ?>" method="post">
				<?php echo csrf_field(); ?>
				<?php echo method_field("delete"); ?>
				<button type="submit" <?php if(count($curso->alumno) >0 ): ?> disabled <?php endif; ?>>Borrar</button>
			</form>
	</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td colspan="4" align="center"><a href="<?php echo e(route('cursos.create')); ?>">Nuevo curso</a></td>
	</tr>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("../layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProyectoLaravel\resources\views/cursos/index.blade.php ENDPATH**/ ?>