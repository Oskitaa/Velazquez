

<?php $__env->startSection("cabecera"); ?>

<h2>Información del curso</h2>

<table border ="1">
	
<tr>
		<th>Nombre</th>
		<th>Horas</th>
        <th>Plazas</th>
        <th>Alumnos</th>
	</tr>
	<tr>
        <?php $__currentLoopData = $curso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($a->nombre); ?></td>
            <td><?php echo e($a->horas); ?></td>
            <td><?php echo e($a->plazas); ?></td>
            <td>
            <?php $__currentLoopData = $a->Alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/alumnos/<?php echo e($b->id); ?>"><?php echo e($b->nombre); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tr>
	<tr>
		<td colspan="4"><a href="/cursos">Volver</a></td>
	</tr>
</table>
<?php $__env->stopSection(); ?> 


<?php echo $__env->make("../layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProyectoLaravel\resources\views/cursos/show.blade.php ENDPATH**/ ?>