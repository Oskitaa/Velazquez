

<?php $__env->startSection("inicio"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("cabecera"); ?>
	
	<h2>Actualizar curso</h2>

	<form method="post" action="/cursos/<?php echo e($curso->id); ?>">
		<?php echo method_field("PUT"); ?>
		<?php echo csrf_field(); ?>
		<table>
			<tr>
				<td>Nombre: <input type="text" name="nombre" value=<?php echo e($curso->nombre); ?>></td>
				<td>Horas curso: <input type="text" name="horas" value=<?php echo e($curso->horas); ?>></td>
				<td>Número de plazas: <input type="text" name="plazas" value=<?php echo e($curso->plazas); ?>></td>
				<select name="categoria">
					<option value="">Seleccione una categoria</option>
					<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value=<?php echo e($categoria->id); ?> <?php if($curso->categoria == $categoria->id): ?> selected <?php endif; ?>><?php echo e($categoria->nombre); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</tr>
			<tr>
				<td colspan="4" align="center"><input type="submit" name="enviar" value="Enviar"></td>
			</tr>
		</table>
	</form>
	<?php if($errors->any()): ?>
    <div>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
	<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make("../layouts.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ese_b\workspace\Velazquez\Servidor\php\ProyectoLaravel\resources\views/cursos/edit.blade.php ENDPATH**/ ?>