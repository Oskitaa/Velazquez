package dwes.spring.tarea.oscar.carballar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
