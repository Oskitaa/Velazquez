from django.apps import AppConfig


class ViajeConfig(AppConfig):
    name = 'viaje'
